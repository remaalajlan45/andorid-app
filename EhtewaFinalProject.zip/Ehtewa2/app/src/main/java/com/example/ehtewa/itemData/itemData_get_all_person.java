package com.example.ehtewa.itemData;

public class itemData_get_all_person {


    public String Get_Fld0 ;
    public String Get_Fld1 ;
    public String Get_Fld2 ;
    public String Get_Fld3 ;
    public String Get_Fld4 ;
    public String Get_Fld5 ;
    public String Get_Fld6 ;
    public String Get_Fld7 ;
    public String Get_Fld8 ;



    public itemData_get_all_person(
            String Get_Fld0  ,
            String Get_Fld1  ,
            String Get_Fld2  ,
            String Get_Fld3  ,
            String Get_Fld4  ,
            String Get_Fld5  ,
            String Get_Fld6  ,
            String Get_Fld7  ,
            String Get_Fld8

    )
    {
        this.Get_Fld0          = Get_Fld0 ;
        this.Get_Fld1          = Get_Fld1 ;
        this.Get_Fld2          = Get_Fld2 ;
        this.Get_Fld3          = Get_Fld3 ;
        this.Get_Fld4          = Get_Fld4 ;
        this.Get_Fld5          = Get_Fld5 ;
        this.Get_Fld6          = Get_Fld6 ;
        this.Get_Fld7          = Get_Fld7 ;
        this.Get_Fld8          = Get_Fld8 ;

    }

    public String Get_Fld0()
    {
        return Get_Fld0;
    }

    public String Get_Fld1()
    {
        return Get_Fld1;
    }

    public String Get_Fld2()
    {
        return Get_Fld2;
    }

    public String Get_Fld3()
    {
        return Get_Fld3;
    }

    public String Get_Fld4()
    {
        return Get_Fld4;
    }

    public String Get_Fld5()
    {
        return Get_Fld5;
    }

    public String Get_Fld6()
    {
        return Get_Fld6;
    }

    public String Get_Fld7()
    {
        return Get_Fld7;
    }

    public String Get_Fld8()
    {
        return Get_Fld8;
    }

}

